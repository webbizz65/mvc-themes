<?php
class Route {

	protected $path;
	protected $values = array();

	public function __construct($path) {

		$this->path = $path;
	}

	public function set($key, $value) {

		$this->values[$key] = $value;
	}

	public function getPath() {

		if(!is_dir($this->path))
		{
			return "<h1 style='font-size:28px;font-weight:600;font-family:sans-serif;color:red;text-align:center'>Path Error:</h1><p style='font-family:sans-serif;font-size:1.1em;color:#888;text-align:center;line-height:2.1em'>The path specified: ( $this->path ) is not a valid path.<br><i><strong>Cannot return request.</strong></i></p>";
		}

		$getpath = ($this->path);

		foreach($this->values as $key => $value)
		{
			$tagToReplace = "{{%$key%}}";
			$getpath = str_replace($tagToReplace, $value, $getpath);
		}
		return $getpath;
	}
}