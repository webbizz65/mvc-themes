<?php
class Template {

	protected $file;
	protected $values = array();

	public function __construct($file) {

		$this->file = $file;
	}

	public function set($key, $value) {

		$this->values[$key] = $value;
	}

	public function output() {

		if(!file_exists($this->file))
		{
			return "<h1 style='font-size:28px;font-weight:600;font-family:sans-serif;color:red;text-align:center'>File Error:</h1><p style='font-family:sans-serif;font-size:1.1em;color:#888;text-align:center;line-height:2.1em'>The file requested: ( $this->file ) was not found on this server.<br><i><strong>Expected Template.</strong></i></p>";
		}

		$output = file_get_contents($this->file);

		foreach($this->values as $key => $value)
		{
			$tagToReplace = "{{%$key%}}";
			$output = str_replace($tagToReplace, $value, $output);
		}
		return $output;
	}
}