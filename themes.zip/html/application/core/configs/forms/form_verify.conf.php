<?php
echo "FORM LINK VERIFY";
/**
 * Validates email link sent to new members
 */