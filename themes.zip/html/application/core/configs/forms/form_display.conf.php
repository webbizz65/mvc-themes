<?php
echo "FORM DISPLAY";
/**
 * Configures display 'which form to display'
 */