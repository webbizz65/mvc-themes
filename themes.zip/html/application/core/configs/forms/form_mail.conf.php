<?php
echo "FORM MAILER";
/**
 * Configures mail then sends to new members
 */