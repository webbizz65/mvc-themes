<?php
 if($_SERVER['REQUEST_METHOD'] === "POST") {
 	include __PATH__ . 'form_validate.mctrl.php';
 } else {
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Log In Required</title>
</head>
<body>

	<center style="margin-top:10%">

		<form action= "" method="POST">
			<header>

				<h1>Login Required</h1>
				<p>The page that you requested requires membership.<br> Please log into your account below, or click the link entitled "Sign Up" to register for free membership.</p>
			</header>
			<div class="label">Username</div>
			<div class="input">
				<input type="text" name="username">
			</div>
			<div class="label">Password</div>
			<div class="input">
				<input type="password" name="pword">
			</div>
			<div class="submit">
				<input type="submit" name="submit" value="Submit">
			</div>
          <p><i>Not a member?</i> <a href= "/?src=.mctrl&targ=register">Sign Up</a></p>
		</form>
         <?php $inputMsg = ""; echo "<i style='color:red'>".$inputMsg."</i>"; ?>
	</center>

	</body>
	</html>
	<?php

}
?>