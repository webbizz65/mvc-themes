<?php
echo "GALLERY<br>";
echo $_SESSION['id'];