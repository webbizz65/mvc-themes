<?php
function getSourceTarget() {
	if(!isset($_GET['src']) || !isset($_GET['targ'])) {
		$source = ".uctrl";
		$target = "home";
	} else
		if(isset($_GET['src']) || isset($_GET['targ'])) {
		$source = htmlspecialchars($_GET['src']);
		$target = htmlspecialchars($_GET['targ']);

		if($_SESSION['id'] === "notlogged" && $source === ".mctrl") {
			$source = ".lrctrl";
			$target = "login";
		} 
	}

	if(!is_dir(__PATH__) || !file_exists(__PATH__ . $target . $source . '.php'))
	{
		echo "Error:<br>Failed to fetch: ( " . __PATH__ . " ), No such file: ( " . $target . $source . ".php )";
		exit;
	}
		$path = new Route(__PATH__);
		$fileName = $target . $source . '.php';

		$path->getPath() . require $fileName;

}
getSourceTarget();