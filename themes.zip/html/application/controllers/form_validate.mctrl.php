<?php
function validateFormInput() {
	$key = "admin123";
	if(!isset($_POST['username']) || !isset($_POST['pword'])) {

		$inputMsg = "User name and valid Password are required.";
	} else {
		$username = htmlspecialchars($_POST['username']);
		$password = htmlspecialchars($_POST['pword']);
	}

	if($password === $key) {
		$inputMsg = "SUCCESS";
		$_SESSION['id'] = $username;
	} else {
		$inputMsg = "User name and or Password could not be verified.";
	} 
	include __APP_CONF__ . 'login.html';
}
validateFormInput();