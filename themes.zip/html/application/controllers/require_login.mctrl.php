<?php
session_start();
if($_SERVER['REQUEST_METHOD'] === "POST") {

	include __APP_CONF__ . 'forms/form_validate.conf.php';
} else {
	echo "<form action='' method='POST'>
	<header><h1>Login Required</h1></header>
	<label for='username'>Username</label>
	<input type='text' name='username'>
	<label for='password'>Password</label>
	<input type='password' name='pword'><br><br>
	<input type='submit' name='submit' value='Log In'>
	</form>";
}