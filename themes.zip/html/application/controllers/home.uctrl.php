<?php
echo "HOME CONTROLLER";
echo "<a href='/?src=.mctrl&targ=gallery'>Gallery</a>";