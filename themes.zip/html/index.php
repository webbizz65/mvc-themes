<?php
require 'application/core/Application.class.php';
Application::init();
?>

