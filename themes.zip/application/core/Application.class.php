<?php
class Application {

	private static function run() {

		self::init();
	}

	public function init() {

		define('__APP_ROOT__', getcwd() . '/');
		define('__APP_CORE__', __APP_ROOT__ . 'application/core/');
		define('__APP_CONF__', __APP_CORE__ . 'configs/');
		define('__APP_SESS__', __APP_CONF__ . 'sessions/');
		define('__APP_FORM__', __APP_CONF__ . 'forms/');
		define('__APP_ADMIN__', __APP_CORE__ . 'admin/');
		define('__APP_PUB__', __APP_ROOT__ . 'public/');
		define('__APP_THEME__', __APP_PUB__ . 'themes/black-n-gold/');
		define('__APP_TPL__', __APP_THEME__ . 'templates/');
		define('__APP_INC__', __APP_THEME__ . 'includes/');
		define('__APP_TPL_ENG__', __APP_CORE__ . 'Template.class');
		define('__APP_ROUTE__', __APP_CORE__ . 'Router.class');
		define('__APP_CTRL__', __APP_ROOT__ . 'application/controllers/');
		define('__APP_CTRL_BASE__', __APP_CTRL__ . 'base.uctrl');
		define('__APP_MODEL__', __APP_ROOT__ . 'application/models/');
		define('__APP_VIEW__', __APP_ROOT__ . 'application/views/');

		require_once __APP_TPL_ENG__ . '.php';
		require_once __APP_ROUTE__ . '.php';
		require_once __APP_CTRL_BASE__ . '.php';
	}
}