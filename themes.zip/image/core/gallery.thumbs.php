<?php
$dir = "images/";
$fileDir = scandir($dir);

$body = new Template(APP_I_IMG);
foreach($fileDir as $value) {
  $body->set('IMAGE', $value);
  echo $body->output();
}
