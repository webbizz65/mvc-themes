<?php
$img = "";

if(isset($_GET['img'])) {
  $img = htmlspecialchars($_GET['img']);

  $body = new Template(APP_T_IMG);
  $body->set('IMAGE', $img);

  echo $body->output();
} else {
  echo "NOTHING TO DO";
  exit;
}