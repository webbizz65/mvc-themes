<?php
define('APP_ROOT', getcwd() . '/');
define('APP_T_IMG', APP_ROOT . 'templates/body.htm');
define('APP_I_IMG', APP_ROOT . 'templates/body.thumbs.htm');
define('__GALLERY__', APP_ROOT . 'core/gallery.php');
define('__GALLERY_B__', APP_ROOT . 'core/gallery.thumbs.php');
define('__TEMP_LATE__', APP_ROOT . 'core/Template.class.php');
define('__IMAGE__', APP_ROOT . 'core/image.php');
  include __TEMP_LATE__;
?>


<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{%PAGE_TITLE%}}</title>
    <meta name="robots" content="index, follow">

<link rel="stylesheet" href="core/css/application.css">
    <script src="core/scripts/jquery.min.js"></script>
  </head>
<body>

   <div class="wrapper">

     <div class="row group">

        <header class="col column6 header">

          <a title="www.nikoleluvz.com" href="/">
       <img src="images/" alt="header image" width="480" height="60">
          </a>
      <nav class="navigation">



          </nav>
       </header>

     </div>

<div class="row group">

    <section id="images" class="col column6">

       <div id="gallery" class="inner_div">

          <?php

            if(!isset($_GET['img'])) {
               include __GALLERY__;
             } else {
               include __IMAGE__;
             }

           ?>

      </div>
      <div id="browser" class="col column6">
          <?php
           if(isset($_GET['img'])) {
             include __GALLERY_B__;
           }

           ?>
      </div>

  </section>

     </div>

  </div>

  </body>
</html>